package edu.pja.mas.s19230.mas.gui.controllers;

import edu.pja.mas.s19230.mas.gui.view.PassengerRouteListView;
import edu.pja.mas.s19230.mas.model.Route;
import edu.pja.mas.s19230.mas.model.Ticket;
import edu.pja.mas.s19230.mas.service.PassengerRouteService;
import edu.pja.mas.s19230.mas.service.TicketService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;

import javax.annotation.PostConstruct;
import javax.swing.*;
import java.util.Iterator;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class PassengerRouteListController {
    private final PassengerRouteListView view;
    private final PassengerRouteService passengerRouteService;
    private final TicketService ticketService;
   

    public void showGUI(MainWindowController mainWindowController) {
        updateRoutesFromDB();
        mainWindowController.showView(view.getMainPanel());

    }

    @PostConstruct
    public void initListeners() {
        view.getPassengerRouteList().addListSelectionListener(e -> {
            if(!e.getValueIsAdjusting()) {
                Route selectedValue = (Route) view.getPassengerRouteList().getSelectedValue();
                System.out.println("route selected: " + selectedValue.getRouteNumber());
                view.getSelectedRouteValue().setText(selectedValue.getRouteNumber());
                List<Ticket> ticketsByRouteId = ticketService.getTicketsByRouteId(selectedValue.getId());
                StringBuilder sb = new StringBuilder();
                for(Iterator<Ticket> it = ticketsByRouteId.iterator(); it.hasNext(); ) {
                    Ticket t = it.next();
                    sb.append(t.getTicketNumber()).append(" ").append(t.getHasTicket().getFirstName()).append(" ").append(t.getHasTicket().getLastName());
                    if(it.hasNext()) {
                        sb.append(", ");
                    }
                }
        view.getTicketsValue().setText(sb.toString());
            }
        });
    }

    private void updateRoutesFromDB() {
        List<Route> routes = passengerRouteService.getAllRoutes();
        DefaultListModel<Route> model = (DefaultListModel<Route>) view.getPassengerRouteList().getModel();
        model.removeAllElements();
        routes.forEach(model :: addElement);

    }
}
