package edu.pja.mas.s19230.mas.repository;

import edu.pja.mas.s19230.mas.model.Train;
import org.springframework.data.repository.CrudRepository;

public interface TrainRepository extends CrudRepository<Train, Long> {
}
