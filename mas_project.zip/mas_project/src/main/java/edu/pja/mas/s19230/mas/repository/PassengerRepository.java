package edu.pja.mas.s19230.mas.repository;

import edu.pja.mas.s19230.mas.model.Passenger;
import org.springframework.data.repository.CrudRepository;

public interface PassengerRepository extends CrudRepository<Passenger, Long> {
}
