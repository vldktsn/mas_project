package edu.pja.mas.s19230.mas.repository;

import edu.pja.mas.s19230.mas.model.Route;
import org.springframework.data.repository.CrudRepository;

public interface RouteRepository extends CrudRepository<Route, Long> {
}
