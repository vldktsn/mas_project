package edu.pja.mas.s19230.mas.repository;

import edu.pja.mas.s19230.mas.model.Station;
import org.springframework.data.repository.CrudRepository;

public interface StationRepository extends CrudRepository<Station,Long> {
}
