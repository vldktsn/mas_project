package edu.pja.mas.s19230.mas.repository;

import edu.pja.mas.s19230.mas.model.PassengerRoute;
import org.springframework.data.repository.CrudRepository;

public interface PassengerRouteRepository extends CrudRepository<PassengerRoute, Long> {
}
