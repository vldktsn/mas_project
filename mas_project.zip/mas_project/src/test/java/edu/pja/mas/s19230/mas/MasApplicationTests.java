package edu.pja.mas.s19230.mas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MasApplicationTests {

    @Test
    void contextLoads() {
    }

}
